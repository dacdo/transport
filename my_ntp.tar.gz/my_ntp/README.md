# my_ntp Cookbook

## Scope

