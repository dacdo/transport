#
# Cookbook Name:: my_ntp

override['ntp']['peer']['minpoll'] = 9

