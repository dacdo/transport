name 'my_ntp'
run_list 'recipe[my_ntp::default]'
#cookbook 'my_ntp', path: '.'
#default_source :supermarket
default_source :artifactory, 'http://13.239.16.84:8081/artifactory/api/chef/EntChef_NonProd_Supermarket'
default_source :artifactory, 'http://13.239.16.84:8081/artifactory/api/chef/ExtComm_Supermarket'
